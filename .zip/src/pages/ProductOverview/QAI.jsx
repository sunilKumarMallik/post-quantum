import React from 'react'

export default function QAI() {
    return (
        <div>
            QAI
        </div>
    )
}
