export const BlogList = [
    {
        id: "1",
        title: "Synergy Quantum is streamlining Military Logistics using Quantum Optimization",
        date: "",
        image:"https://static.wixstatic.com/media/d3f37f_24c2d4e6fc70455aaca4cc7f0e7f61e7~mv2.jpg/v1/fill/w_740,h_416,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/d3f37f_24c2d4e6fc70455aaca4cc7f0e7f61e7~mv2.jpg",
        views: ""
    },
    {
        id: "1",
        title: "2024: THE YEAR OF QUANTUM POSSIBILITIES",
        date: "",
        image:"https://static.wixstatic.com/media/d3f37f_85daeea361f4401b954fc495ff718365~mv2.png/v1/fill/w_740,h_425,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/d3f37f_85daeea361f4401b954fc495ff718365~mv2.png",
        views: ""
    },
    {
        id: "1",
        title: "SYNERGY QUANTUM SOLUTION LAB TO BE SETUP BY IIIT HYDERABAD IN PARTNERSHIP",
        image:"https://static.wixstatic.com/media/d3f37f_fbaca081550042458d2286cfdb146778~mv2.png/v1/fill/w_330,h_280,al_c,lg_1,q_85,enc_auto/d3f37f_fbaca081550042458d2286cfdb146778~mv2.png",
        date: "",
        views: ""
    },
    {
        id: "1",
        title: "WISeKey Signs Strategic Partnership Agreement with Synergy Quantum",
        image:"https://static.wixstatic.com/media/d3f37f_e49108ec3aa148998419ad3bddc8ef70~mv2.webp",
        date: "",
        views: ""
    },
    {
        id: "1",
        title: "SQ makes foray into secure semiconductors: hires Ex-Group Executive of STMicroelectronics",
        image:"https://static.wixstatic.com/media/d3f37f_493c56a867854ed5bd7542ffddc2b586~mv2.webp",
        date: "",
        views: ""
    },
    {
        id: "1",
        title: "Synergy Quantum SA, a Swiss Start-up signs Agreement with Indian Government for a joint",
        image:"https://static.wixstatic.com/media/d3f37f_6777b8959c62444a87a2104436da8837~mv2.webp",
        date: "",
        views: ""
    },
]