
export const navItem = [

  {
    label: "Quantum Safe Ecosystem",
    to: "/services",
    subMenu: [
      { label: "Hybrid PQ VPN", to: "/newsroom" },
      { label: "Messanging - PQ Chat", to: "/blogging" },
      { label: "Identity", to: "/blogging" },
      { label: "Approval As a Service", to: "/blogging" },
    ],
  },
  {
    label: "Industries",
    to: "/services",
    subMenu: [
      
    ],
  },
  {
    label: "PQ Insights",
    to: "/services",
    subMenu: [
      { label: "PQ-videos", to: "/culture" },

    ],
  },
  {
    label: "Abouts US",
    to: "/services",
    subMenu: [
      { label: "The Company", to: "/culture" },
      { label: "Contact Details", to: "/culture" },

    ],
  },
];
